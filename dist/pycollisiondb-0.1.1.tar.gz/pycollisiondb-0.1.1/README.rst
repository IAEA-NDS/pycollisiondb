*****************************
Introduction to PyCollisionDB
*****************************



PyCollisionDB is a Python package for interacting with CollisionDB, a database
of plasma collisional cross sections and rate coefficients.
